package com.advancedtours.Repository;
import com.advancedtours.Entity.AdminEntity;
import org.springframework.data.jpa.repository.JpaRepository;
public interface AdminRepository extends JpaRepository<AdminEntity,String>{
}
